﻿# Servidor web mínimo para VER el recorrido sin internet y sin instalar nada.
# Lo usa "ver-recorrido.bat". Solo atiende a este equipo (localhost).
param(
  [string]$Raiz = (Join-Path $PSScriptRoot "sitio"),
  [int]$Puerto = 8361
)

$ErrorActionPreference = "Stop"
$Raiz = (Resolve-Path $Raiz).Path
$tipos = @{
  ".html" = "text/html; charset=utf-8"; ".js" = "text/javascript; charset=utf-8"; ".css" = "text/css; charset=utf-8"
  ".json" = "application/json; charset=utf-8"; ".webmanifest" = "application/manifest+json"; ".jpg" = "image/jpeg"; ".jpeg" = "image/jpeg"; ".png" = "image/png"
  ".webp" = "image/webp"; ".gif" = "image/gif"; ".svg" = "image/svg+xml"; ".ico" = "image/x-icon"
  ".mp3" = "audio/mpeg"; ".m4a" = "audio/mp4"; ".aac" = "audio/aac"; ".ogg" = "audio/ogg"; ".wav" = "audio/wav"
  ".mp4" = "video/mp4"; ".txt" = "text/plain; charset=utf-8"
}

# Busca un puerto libre
$oyente = $null
for ($p = $Puerto; $p -lt $Puerto + 20; $p++) {
  try {
    $oyente = New-Object System.Net.HttpListener
    $oyente.Prefixes.Add("http://localhost:$p/")
    $oyente.Start()
    $Puerto = $p
    break
  } catch { $oyente = $null }
}
if (-not $oyente) { Write-Host "No se encontró un puerto libre."; exit 1 }

$url = "http://localhost:$Puerto/"
Write-Host ""
Write-Host "  Recorrido 360 abierto en $url"
Write-Host "  Deja esta ventana abierta mientras lo usas. Ciérrala para terminar."
Write-Host ""
Start-Process $url

while ($oyente.IsListening) {
  $ctx = $oyente.GetContext()
  $res = $ctx.Response
  try {
    $ruta = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath).TrimStart("/")
    if ($ruta -eq "" -or $ruta.EndsWith("/")) { $ruta += "index.html" }
    $archivo = [IO.Path]::GetFullPath((Join-Path $Raiz $ruta))
    if (-not $archivo.StartsWith($Raiz) -or -not [IO.File]::Exists($archivo)) {
      $res.StatusCode = 404
      $res.Close()
      continue
    }
    $ext = [IO.Path]::GetExtension($archivo).ToLower()
    $res.ContentType = if ($tipos.ContainsKey($ext)) { $tipos[$ext] } else { "application/octet-stream" }
    $res.AddHeader("Accept-Ranges", "bytes")
    $flujo = [IO.File]::OpenRead($archivo)
    try {
      $total = $flujo.Length
      $inicio = 0; $fin = $total - 1
      $rango = $ctx.Request.Headers["Range"]
      if ($rango -match "bytes=(\d*)-(\d*)") {   # necesario para adelantar/atrasar audios
        if ($matches[1]) { $inicio = [long]$matches[1] }
        if ($matches[2]) { $fin = [Math]::Min([long]$matches[2], $total - 1) }
        $res.StatusCode = 206
        $res.AddHeader("Content-Range", "bytes $inicio-$fin/$total")
      }
      $res.ContentLength64 = $fin - $inicio + 1
      if ($ctx.Request.HttpMethod -eq "HEAD") { continue }
      $flujo.Position = $inicio
      $buffer = New-Object byte[] 65536
      $quedan = $res.ContentLength64
      while ($quedan -gt 0) {
        $n = $flujo.Read($buffer, 0, [Math]::Min($buffer.Length, $quedan))
        if ($n -le 0) { break }
        $res.OutputStream.Write($buffer, 0, $n)
        $quedan -= $n
      }
    } finally { $flujo.Close() }
  } catch {
    # el navegador canceló la descarga (por ejemplo al cambiar de escena): se ignora
  } finally {
    try { $res.Close() } catch {}
  }
}
