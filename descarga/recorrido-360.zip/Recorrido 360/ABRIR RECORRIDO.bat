@echo off
chcp 65001 >nul
title Recorrido 360
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0servidor-local.ps1" -Raiz "%~dp0sitio"
pause
