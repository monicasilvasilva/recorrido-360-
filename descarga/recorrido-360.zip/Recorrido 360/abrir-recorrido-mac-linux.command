#!/bin/sh
# Mac / Linux: abre el recorrido sin internet (requiere python3)
cd "$(dirname "$0")/sitio" || exit 1
( sleep 1; open "http://localhost:8361/" 2>/dev/null || xdg-open "http://localhost:8361/" ) &
echo "Recorrido 360 en http://localhost:8361/  (cierra esta ventana para terminar)"
python3 -m http.server 8361 --bind 127.0.0.1
